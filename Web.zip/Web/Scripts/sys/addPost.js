﻿/// <reference path="common.js" />
/// <reference path="DataService.js" />


String.prototype.format = function () {
    var str = this;
    for (var i = 0; i < arguments.length; i++) {
        var reg = new RegExp("\\{" + i + "\\}", "gm");
        str = str.replace(reg, arguments[i]);
    }
    return str;
}


var newPostManager = newPostManager || {},
    newPostManager = function () {
        var
            init = function () {
                pageEvents();

                getProperties();
            },
            getProperties = function () {
                // Social settings
                var uRL = '/api/data/GetDataDirect',
                    data = { actionName: 'Settings_Social' },
                    settingCallBack = function (data) {
                        data = commonManger.decoData(data).list;


                        var
                            //                   0                      1                   2                     3                   4                     5                   6
                            myVariables = ['Facebook_Active', 'Facebook_PageURL', 'Facebook_AccessToken', 'Instagram_Active', 'Instagram_UserID', 'Instagram_Password', 'Facebook_PageID'],
                            dataJson = JSON.stringify(data);



                        var fbActive = $.grep(data, function (v, k) {
                            if (v.Name === myVariables[0])
                                return v.Value;
                        }),
                            fbPostURL = $.grep(data, function (v, k) {
                                if (v.Name === myVariables[1])
                                    return v.Value;
                            }),
                            fbURL = $.grep(data, function (v, k) {
                                if (v.Name === myVariables[6])
                                    return v.Value;
                            }),
                            fbToken = $.grep(data, function (v, k) {
                                if (v.Name === myVariables[2])
                                    return v.Value;
                            }),
                            instActive = $.grep(data, function (v, k) {
                                if (v.Name === myVariables[3])
                                    return v.Value;
                            }),
                            instID = $.grep(data, function (v, k) {
                                if (v.Name === myVariables[4])
                                    return v.Value;
                            }),
                            instPass = $.grep(data, function (v, k) {
                                if (v.Name === myVariables[5])
                                    return v.Value;
                            }),
                            socialHtml = '';


                        // showing social page
                        if (fbActive[0].Value === 'True') {
                            socialHtml = `<div class="so-options" data-url="${fbPostURL[0].Value}"  data-token="${fbToken[0].Value}"><label class="middle"><input class="ace" type="checkbox" checked /><span class="lbl">Facebook</span></label>&nbsp;<i class="fa fa-arrow-right"></i> <a href="http://facebook.com/${fbURL[0].Value}" target="_blank"><i class="fa fa-2x fa-facebook"></i></a></div>`;
                        }
                        if (instActive[0].Value === 'True') {
                            socialHtml += `<div class="so-options" data-url="${instID[0].Value}"  data-token="${instPass[0].Value}"><label class="middle"><input class="ace" type="checkbox" checked /><span class="lbl">Instagram</span></label>&nbsp;<i class="fa fa-arrow-right"></i> <a href="http://instagram.com/${instID[0].Value}" target="_blank"><i class="fa fa-2x fa-instagram"></i></a></div>`;
                        }
                        //if (twActive[0].Value === 'True') {
                        //    socialHtml += `<div data-url="${twURL[0].Value}"  data-token="${twToken[0].Value}"><label class="middle"><input class="ace" type="checkbox" checked /><span class="lbl">Facebook</span></label>&nbsp;<i class="fa fa-arrow-right"></i><a href="http://twitter.com/DarAlQimahFashion" target="_blank"><i class="fa fa-2x fa-twitter"></i></a></div>`;
                        //}


                        $('.socialActivePages').html(socialHtml);

                    };

                dataService.callAjax('GET', data, uRL, settingCallBack, commonManger.errorException);
            },
            getImageName = function () {
                var nme = $('input[type=file]').eq(0).val().replace(/.*(\/|\\)/, '');
                return nme.split(".")[0];
            },
            uploadImage = function (imgStr) {
                var uRL = "/api/Upload/Save",
                    uploadCallBack = function (data) {
                        console.log(data);
                    },
                    data = { Name: imgStr };


                dataService.callAjax('POST', JSON.stringify(data), uRL,
                    uploadCallBack, commonManger.errorException);
            },
            potingToSocial = function () {
                var post = {
                    uRL: '/api/social/posttoall',
                    img: $('#picture img'),
                    fbCtrl: $('.so-options:eq(0)'),
                    insCtrl: $('.so-options:eq(1)'),

                    // avialable social pages checked
                    fbActive() { return this.fbCtrl.find('input[type="checkbox"]').is(':checked') ? true : false; },
                    insActive() { return this.insCtrl.find('input[type="checkbox"]').is(':checked') ? true : false; },

                    fbPostUrl() { return this.fbCtrl.data('url'); },
                    fbToken() { return this.fbCtrl.data('token'); },

                    insID() { return this.insCtrl.data('url'); },
                    insToken() { return this.insCtrl.data('token'); },

                    msg: $('#message').val(),
                    imageBase64() { return this.img.length ? this.img.attr('src').split(',').pop() : '' },
                    showMessage: function (typeID, message) {
                        var _msg = '<div class="alert alert-' + (typeID > 1 ? 'danger' : 'success') + '">' + message + '</div>';
                        $('.message').html(_msg);
                    },
                    postedSocialCallBack: function (d) {
                        showMessage(1, 'This post has been added to your social page.');
                    }
                },
                    _data = {
                        Message: post.msg,
                        ImageBase64: post.imageBase64(),
                        FacebookActive: post.fbActive(),
                        InstagramActive: post.insActive(),
                        FacebookPostURL: post.fbPostUrl(),
                        FacebookToken: post.fbToken(),
                        InstagramID: post.insID(),
                        InstagramToken: post.insToken(),
                    };

                //validation
                if (_data.ImageBase64.length < 5) {
                    commonManger.showMessage('Image is required', 'Please select an image.');
                    $('#image').closest('div.form-group').addClass('text-danger');
                    return;
                }
                if (_data.Message.length < 5) {
                    commonManger.showMessage('Message is required', 'Please enter post message (minimum 5 characters).');
                    $('#message').closest('div.form-group').addClass('text-danger');
                    return;
                }
                if (!_data.FacebookActive && !_data.InstagramActive) {
                    commonManger.showMessage('Post to is required', 'Please select at least one from Post to.');
                    $('.so-options').closest('div.form-group').addClass('text-danger');
                    return;
                }

                // get data
                dataService.callAjax('POST', JSON.stringify(_data), post.uRL, post.postedSocialCallBack, commonManger.errorException);
            },
            pageEvents = function () {

                $('#image').ace_file_input({
                    style: 'well',
                    btn_choose: 'Drop images here or click to choose',
                    btn_change: null,
                    no_icon: 'ace-icon fa fa-picture-o',
                    droppable: true,
                    thumbnail: 'large', //| true | 
                    whitelist: 'gif|png|jpg|jpeg',
                    blacklist: 'exe|php',
                    allowExt: ["jpeg", "jpg", "png", "gif", "bmp"],
                    allowMime: ["image/jpg", "image/jpeg", "image/png", "image/gif", "image/bmp"],
                    before_change: function (files, dropped) {
                        //Check an example below
                        //or examples/file-upload.html
                        return true;
                    },
                    before_remove: function () {
                        return true;
                    },
                    preview_error: function (filename, error_code) {
                        //name of the file that failed
                        //error_code values
                        //1 = 'FILE_LOAD_FAILED',
                        //2 = 'IMAGE_LOAD_FAILED',
                        //3 = 'THUMBNAIL_FAILED'
                        //alert(error_code);
                    }
                }).on('change', function () {

                    var images = $(this).data('ace_input_files'),
                        countFiles = $(this)[0].files.length,
                        imgPath = $(this)[0].value,
                        imgSize = $(this)[0].size,
                        extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();


                    console.log($(this)[0].files[0]);


                    //var _img = new Image();
                    //_img.src = base64String;
                    //_img.onload = function () {
                    //    if (this.width < 200) {
                    //        commonManger.showMessage('Image is too small:', 'Please select a large image mini width 200 px.');
                    //        return;
                    //    }

                    //    // upload img to sever
                    //    //uploadImage(base64String);
                    //};




                    //console.log($(this).data('ace_input_files'));
                    //console.log($(this).data('ace_input_method'));
                });

                // events
                // start post to all pages
                $('#SendAll').click(function (e) {
                    e.preventDefault();
                    potingToSocial();

                });


                // image selection
                $("#image").on('change', function () {
                    //Get count of selected files
                    var countFiles = $(this)[0].files.length,
                        imgPath = $(this)[0].value,
                        extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase(),
                        image_holder = $("#picture");

                    image_holder.empty();

                    if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") {
                        if (typeof (FileReader) != "undefined") {
                            //loop for each file selected for uploaded.
                            for (var i = 0; i < countFiles; i++) {

                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    var base64String = e.target.result;


                                    //------------------------- -------------------------
                                    //------------------------- -------------------------
                                    var _img = new Image();
                                    _img.src = base64String;
                                    _img.onload = function () {
                                        if (this.width < 200) {
                                            commonManger.showMessage('Image is too small:', 'Please select a large image mini width 200 px.');
                                            return;
                                        }



                                        $("<img />", {
                                            "src": base64String,
                                            "class": "thumb-image"
                                        }).appendTo(image_holder);
                                        image_holder.show();
                                        reader.readAsDataURL($(this)[0].files[i]);
                                        // upload img to sever
                                        //uploadImage(base64String);
                                    };
                                    //------------------------- -------------------------
                                    //------------------------- -------------------------
                                }

                            }
                        } else {
                            alert("This browser does not support FileReader.");
                        }
                    } else {
                        alert("Pls select only images");
                    }
                });
            };

        return {
            init: init
        };

    }();


newPostManager.init();