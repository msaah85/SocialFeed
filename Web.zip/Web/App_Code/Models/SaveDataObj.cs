﻿
// models
public class SaveDataObj
{
    public string actionName { get; set; }
    public string[] names { get; set; }
    public string[] values { get; set; }
}