﻿using System;
using System.Web.UI;

public partial class Site_Mobile : MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
